{
  "package_name": "com.arg.hdobox",
  "download_url": "https://dl.dropboxusercontent.com/scl/fi/cb4hdplbtb27gau6jih7n/X_HDO.apk?rlkey=gj21vapzqoycabqcvgwt4u4jq&st=qkayb6ov&dl=0"
}

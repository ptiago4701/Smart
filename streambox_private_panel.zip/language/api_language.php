
<?php
	$app_lang = array();

	// for invalid email format
	$app_lang['invalid_email_format']="Email format is invalid !";

	// for otp sent
	$app_lang['otp_sent']="OTP has been sent on your mail.";

	// for email not found
	$app_lang['email_not_found']="Email is not found !";

	// for invalid password
	$app_lang['invalid_password']="Password is invalid !";

	// for account deactive
	$app_lang['account_deactive']="Sorry ! Your account is suspended";

	// for lagin success
	$app_lang['login_success']="Login successfully.";

	// for lagin failed
	$app_lang['login_fail']="Login is failed !";

	// for email exist
	$app_lang['email_exist']="Email is already exist !";

	// for register success
	$app_lang['register_success']="Registration successfully.";

	// for register failed
	$app_lang['register_fail']="Registration is failed !";

	// for comment success
	$app_lang['comment_success']="Comment submitted successfully.";

	// for comment failed
	$app_lang['comment_fail']="Comment is failed";

	// for comment delete
	$app_lang['comment_delete']="Comment is deleted.";

	// for report success
	$app_lang['report_success']="Report submitted successfully.";

	// for report failed
	$app_lang['report_fail']="Report is failed";

	// for report already submitted
	$app_lang['report_already']="Report already submitted !";

	// for search not found
	$app_lang['search_result']="Keyword is not found ! Try different keyword";

	// for password send in mail
	$app_lang['password_sent_mail']="Password has been sent on your mail.";	

	// for added success
	$app_lang['add_success']="Added successfully.";

	// for added failed
	$app_lang['add_fail']="Adding is failed !";

	// for updated success
	$app_lang['update_success']="Updated successfully.";

	// for updated failed
	$app_lang['update_fail']="Updatation is failed !";
	
	// for post upload
	$app_lang['post_updated']="Post is updated successfully";

	// for post upload wait approval
	$app_lang['post_upload_wait']="Your post is successfully submitted. Wait until admin approve it";	
	
	// for upload normal user post error
	$app_lang['post_upload_error']="You are not a reporter. So you can't upload/update post !";	

	// for message sent
	$app_lang['msg_sent']="Message has been sent.";

	// rating messages
	$app_lang['rate_success']="You have successfully rated";
	$app_lang['rate_already']="You have already rated !";

	// for favourite
	$app_lang['favourite_success']="Added to Favourite";

	// for favourite remove
	$app_lang['favourite_remove_success']="Removed from Favourite";

	// for favourite remove error
	$app_lang['favourite_remove_error']="Error in remove from Favourite";

	// for no data
	$app_lang['no_data_msg']="Sorry no data found !";
	
	// All kind of email template label

	// for email dear label
	$app_lang['dear_lbl']="Dear";

	// for email your password label
	$app_lang['your_password_lbl']="Your Password is";

	// for registration email subject
	$app_lang['register_mail_lbl']="[IMPORTANT] ### Registration completed";  // don't remove ### that will be replaced by you app name

	// for reporter request approve mail subject
	$app_lang['reporter_sub_lbl']="[IMPORTANT] ### Reporter Information";  // don't remove ### that will be replaced by you app name

	// for reporter request message
	$app_lang['reporter_req_msg']="Your request for reporter is approved by admin";

	// for reporter request message new line
	$app_lang['reporter_req_msg2']="You can access/upload news from Admin Panel. Admin panel url is: ";

	// for forgot password email subject
	$app_lang['forgot_password_sub_lbl']="[IMPORTANT] ### Forgot Password Information";  // don't remove ### that will be replaced by you app name

	// for email copyright label
	$app_lang['welcome_lbl']="Welcome";

	// for google registration success message
	$app_lang['google_register_msg']="You have successfully registration with google";

	// for facebook registration success message
	$app_lang['facebook_register_msg']="You have successfully registration with facebook";

	// for normal registration success message
	$app_lang['normal_register_msg']="Your registration is successfully completed";

	// for thank you
	$app_lang['thank_you_lbl']="Thank you for using";

	// for email copyright label
	$app_lang['email_copyright']="Copyright ©";
	
	// for like
	$app_lang['like_success']="Add";

	// for like remove
	$app_lang['like_remove_success']="Removed";
	
	// for like remove error
	$app_lang['like_remove_error']="Error";
	
	// for no data
	$app_lang['no_data_msg']="Sorry no data found !";

	// for remove image success
	$app_lang['img_remove_success']="Image is removed.";
	
	$app_lang['delete_success']="Delete successfully";
	
	// for report success
	$app_lang['suggest_success']="Suggest submitted successfully.";
	
	// for transaction success
	$app_lang['transaction_success']="Transaction successfully.";

	// for transaction failed
	$app_lang['transaction_fail']="Transaction is failed";
	
	// for remove success
	$app_lang['remove_success']="Remove successfully.";
	
	
    // for follow
	$app_lang['follow_success']="Added to Follow";

	// for follow remove
	$app_lang['follow_remove_success']="Removed to Follow";

	// for follow remove error
	$app_lang['follow_remove_error']="Error in remove from UnFollow";

?>